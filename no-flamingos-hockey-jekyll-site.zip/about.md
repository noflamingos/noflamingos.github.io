---
title: About
layout: default
permalink: /about/
---

No Flamingos Hockey is a simple drill library built for sharing drills with the team.

- Browse drills by category
- Search by name + short description
- Open any drill for full setup, coaching points, variations, and optional video
- Print-friendly drill sheets

