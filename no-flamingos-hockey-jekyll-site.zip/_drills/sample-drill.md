---
title: "Sample Drill (Replace Me)"
short_description: "A short one-liner used on cards and search."
thumbnail: "/assets/images/drills/sample-drill/thumb.png"
images:
  - "/assets/images/drills/sample-drill/1.png"
setup: |
  Put players in two lines. Coach has pucks in the middle.
full_description: |
  On the whistle, first player from each line races for the puck and attacks the net.
coaching_points:
  - "Head up after retrieval"
  - "Explode out of turns"
equipment:
  - "Pucks"
  - "2 nets"
categories:
  - "warm-up"
  - "battle"
variations: |
  Make it 2v2. Add a pass to a support player.
youtube: ""
---
